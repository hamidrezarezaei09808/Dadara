package ir.dadara.app

import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.floor

/** تبدیل تقویم میلادی/شمسی بر اساس الگوریتم استاندارد jalaali */
object Jalali {

    data class JDate(val jy: Int, val jm: Int, val jd: Int)

    private fun div(a: Int, b: Int): Int = floor(a.toDouble() / b.toDouble()).toInt()
    private fun mod(a: Int, b: Int): Int = a - b * floor(a.toDouble() / b.toDouble()).toInt()

    private val breaks = intArrayOf(
        -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210,
        1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178
    )

    /** returns [leap, gy, march] */
    private fun jalCal(jy: Int): IntArray {
        val bl = breaks.size
        val gy = jy + 621
        var leapJ = -14
        var jp = breaks[0]
        var jump = 0
        for (i in 1 until bl) {
            val jm = breaks[i]
            jump = jm - jp
            if (jy < jm) break
            leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4)
            jp = jm
        }
        var n = jy - jp
        leapJ += div(n, 33) * 8 + div(mod(n, 33) + 3, 4)
        if (mod(jump, 33) == 4 && jump - n == 4) leapJ += 1
        val leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150
        val march = 20 + leapJ - leapG
        if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33
        var leap = mod(mod(n + 1, 33) - 1, 4)
        if (leap == -1) leap = 4
        return intArrayOf(leap, gy, march)
    }

    fun isLeapJalali(jy: Int): Boolean = jalCal(jy)[0] == 0

    fun jalaliMonthLength(jy: Int, jm: Int): Int = when {
        jm <= 6 -> 31
        jm <= 11 -> 30
        else -> if (isLeapJalali(jy)) 30 else 29
    }

    fun g2d(gy: Int, gm: Int, gd: Int): Int {
        var d = div((gy + div(gm - 8, 6) + 100100) * 1461, 4) +
            div(153 * mod(gm + 9, 12) + 2, 5) + gd - 34840408
        d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752
        return d
    }

    fun d2g(jdn: Int): Triple<Int, Int, Int> {
        var j = 4 * jdn + 139361631
        j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908
        val i = div(mod(j, 1461), 4) * 5 + 308
        val gd = div(mod(i, 153), 5) + 1
        val gm = mod(div(i, 153), 12) + 1
        val gy = div(j, 1461) - 100100 + div(8 - gm, 6)
        return Triple(gy, gm, gd)
    }

    fun j2d(jy: Int, jm: Int, jd: Int): Int {
        val r = jalCal(jy)
        return g2d(r[1], 3, r[2]) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1
    }

    fun d2j(jdn: Int): JDate {
        val gy = d2g(jdn).first
        var jy = gy - 621
        val r = jalCal(jy)
        val jdn1f = g2d(gy, 3, r[2])
        var k = jdn - jdn1f
        if (k >= 0) {
            if (k <= 185) {
                val jm = 1 + div(k, 31)
                val jd = mod(k, 31) + 1
                return JDate(jy, jm, jd)
            } else {
                k -= 186
            }
        } else {
            jy -= 1
            k += 179
            if (jalCal(jy)[0] == 1) k += 1
        }
        val jm = 7 + div(k, 30)
        val jd = mod(k, 30) + 1
        return JDate(jy, jm, jd)
    }

    // ---------- helpers ----------

    fun todayJdn(): Int {
        val d = LocalDate.now()
        return g2d(d.year, d.monthValue, d.dayOfMonth)
    }

    fun today(): JDate = d2j(todayJdn())

    fun jdnOf(j: JDate): Int = j2d(j.jy, j.jm, j.jd)

    val monthNames = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    fun weekdayName(jdn: Int): String {
        // 1979-01-01 was شنبه
        val days = listOf("دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه", "یکشنبه")
        val base = g2d(1979, 1, 1) // شنبه
        val idx = mod(jdn - base, 7)
        return days[idx]
    }

    fun format(j: JDate): String =
        "${fa(j.jd)} ${monthNames[j.jm - 1]} ${fa(j.jy)}"

    fun formatShort(j: JDate): String =
        "${faDigits(pad2(j.jd))}/${faDigits(pad2(j.jm))}/${faDigits(j.jy.toString())}"

    fun pad2(n: Int): String = if (n < 10) "0$n" else n.toString()
}

/** تبدیل ارقام فارسی/عربی به انگلیسی برای ورودی عددی */
fun toEnDigits(s: String): String {
    val fa = "۰۱۲۳۴۵۶۷۸۹"
    val ar = "٠١٢٣٤٥٦٧٨٩"
    return s.map { c ->
        when {
            c in '۰'..'۹' -> fa.indexOf(c).toString()
            c in '٠'..'٩' -> ar.indexOf(c).toString()
            else -> c.toString()
        }
    }.joinToString("")
}

fun faDigits(s: String): String {
    val fa = "۰۱۲۳۴۵۶۷۸۹"
    return s.map { if (it in '0'..'9') fa[it - '0'] else it }.joinToString("")
}

fun fa(n: Int): String = faDigits(n.toString())

fun faTime(hhmm: String): String {
    val parts = hhmm.split(":")
    return if (parts.size == 2) "${faDigits(parts[0])}:${faDigits(parts[1])}" else hhmm
}

/** تاریخ جلالی از رشته‌ی "1404/02/15" یا "1404-2-5" */
fun parseJalali(s: String): Jalali.JDate? {
    val clean = toEnDigits(s).replace("-", "/").replace(".", "/").trim()
    val p = clean.split("/").map { it.trim().toIntOrNull() }
    if (p.size != 3) return null
    val y = p[0] ?: return null
    val m = p[1] ?: return null
    val d = p[2] ?: return null
    if (y < 1300 || y > 1500) return null
    if (m < 1 || m > 12) return null
    if (d < 1 || d > Jalali.jalaliMonthLength(y, m)) return null
    return Jalali.JDate(y, m, d)
}

/** ساعت معتبر "HH:mm" */
fun parseTime(s: String): String? {
    val clean = toEnDigits(s).replace("٫", ":").replace(".", ":").trim()
    val p = clean.split(":").map { it.trim().toIntOrNull() }
    if (p.size != 2) return null
    val h = p[0] ?: return null
    val m = p[1] ?: return null
    if (h !in 0..23 || m !in 0..59) return null
    return "%02d:%02d".format(h, m)
}

/** افزودن روز به تاریخ جلالی */
fun addDaysJalali(j: Jalali.JDate, days: Int): Jalali.JDate =
    Jalali.d2j(Jalali.j2d(j.jy, j.jm, j.jd) + days)
