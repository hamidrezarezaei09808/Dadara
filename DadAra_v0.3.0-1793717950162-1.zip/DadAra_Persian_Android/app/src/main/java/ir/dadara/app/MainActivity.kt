package ir.dadara.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

private val Navy = Color(0xFF101D35)
private val NavyLight = Color(0xFF1A2D4D)
private val Gold = Color(0xFFC8A65A)
private val Cream = Color(0xFFF7F4EC)
private val Ink = Color(0xFF1D2635)
private val Muted = Color(0xFF737B89)
private val SurfaceWhite = Color(0xFFFFFFFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                DadAraApp()
            }
        }
    }
}

@Composable
fun DadAraApp() {
    val ctx = LocalContext.current

    var selectedTab by remember { mutableStateOf("خانه") }
    var showAddCase by remember { mutableStateOf(false) }
    var editCase by remember { mutableStateOf<CaseItem?>(null) }
    var showAddClient by remember { mutableStateOf(false) }
    var editClient by remember { mutableStateOf<Client?>(null) }
    var showAddHearing by remember { mutableStateOf(false) }
    var editHearing by remember { mutableStateOf<Hearing?>(null) }

    var cases by remember { mutableStateOf<List<CaseItem>>(emptyList()) }
    var clients by remember { mutableStateOf<List<Client>>(emptyList()) }
    var hearings by remember { mutableStateOf<List<Hearing>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }

    // بارگذاری داده‌های ذخیره‌شده
    LaunchedEffect(Unit) {
        cases = Store.loadCases(ctx).ifEmpty {
            listOf(
                CaseItem(newId(), "مطالبه وجه قرارداد", "نمونه: علی رضایی", "۱۴۰۵/۱۲۳", "دادگاه عمومی حقوقی", "در جریان", "پرونده نمونه — قابل ویرایش یا حذف", System.currentTimeMillis()),
                CaseItem(newId() + 1, "الزام به تنظیم سند رسمی", "نمونه: مریم احمدی", "۱۴۰۵/۱۲۴", "شورای حل اختلاف", "در انتظار اقدام", "", System.currentTimeMillis())
            )
        }
        clients = Store.loadClients(ctx)
        hearings = Store.loadHearings(ctx)
        loaded = true
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy,
            secondary = Gold,
            background = Cream,
            surface = SurfaceWhite,
            onPrimary = Color.White,
            onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Cream,
            bottomBar = {
                NavigationBar(containerColor = Navy, contentColor = Color.White) {
                    val tabs = listOf("خانه", "پرونده‌ها", "جلسات", "موکلان")
                    val icons = listOf("⌂", "▤", "◷", "♙")
                    tabs.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = { Text(icons[index], fontSize = 20.sp) },
                            label = { Text(tab, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold,
                                selectedTextColor = Gold,
                                indicatorColor = NavyLight,
                                unselectedIconColor = Color.LightGray,
                                unselectedTextColor = Color.LightGray
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                "خانه" -> HomeScreen(
                    cases = cases,
                    clients = clients,
                    hearings = hearings,
                    modifier = Modifier.padding(padding),
                    onAddCase = { showAddCase = true },
                    onOpenCases = { selectedTab = "پرونده‌ها" },
                    onOpenHearings = { selectedTab = "جلسات" }
                )
                "پرونده‌ها" -> CasesScreen(
                    cases = cases,
                    modifier = Modifier.padding(padding),
                    onAddCase = { showAddCase = true },
                    onEditCase = { editCase = it },
                    onDeleteCase = { c ->
                        cases = cases.filterNot { it.id == c.id }
                        Store.saveCases(ctx, cases)
                    }
                )
                "جلسات" -> HearingsScreen(
                    hearings = hearings,
                    cases = cases,
                    modifier = Modifier.padding(padding),
                    onAdd = { showAddHearing = true },
                    onEdit = { editHearing = it },
                    onDelete = { h ->
                        hearings = hearings.filterNot { it.id == h.id }
                        Store.saveHearings(ctx, hearings)
                    }
                )
                "موکلان" -> ClientsScreen(
                    clients = clients,
                    cases = cases,
                    modifier = Modifier.padding(padding),
                    onAdd = { showAddClient = true },
                    onEdit = { editClient = it },
                    onDelete = { c ->
                        clients = clients.filterNot { it.id == c.id }
                        Store.saveClients(ctx, clients)
                    }
                )
            }
        }

        if (showAddCase) {
            CaseDialog(
                onDismiss = { showAddCase = false },
                onSave = { title, client, number, court, status, note ->
                    cases = listOf(
                        CaseItem(newId(), title, client, number, court, status, note, System.currentTimeMillis())
                    ) + cases
                    Store.saveCases(ctx, cases)
                    showAddCase = false
                    selectedTab = "پرونده‌ها"
                }
            )
        }
        editCase?.let { c ->
            CaseDialog(
                initial = c,
                onDismiss = { editCase = null },
                onSave = { title, client, number, court, status, note ->
                    cases = cases.map { if (it.id == c.id) it.copy(title = title, client = client, caseNumber = number, court = court, status = status, note = note) else it }
                    Store.saveCases(ctx, cases)
                    editCase = null
                }
            )
        }

        if (showAddClient) {
            ClientDialog(
                onDismiss = { showAddClient = false },
                onSave = { name, phone, note ->
                    clients = listOf(Client(newId(), name, phone, note)) + clients
                    Store.saveClients(ctx, clients)
                    showAddClient = false
                }
            )
        }
        editClient?.let { c ->
            ClientDialog(
                initial = c,
                onDismiss = { editClient = null },
                onSave = { name, phone, note ->
                    clients = clients.map { if (it.id == c.id) it.copy(name = name, phone = phone, note = note) else it }
                    Store.saveClients(ctx, clients)
                    editClient = null
                }
            )
        }

        if (showAddHearing) {
            HearingDialog(
                cases = cases,
                onDismiss = { showAddHearing = false },
                onSave = { h ->
                    hearings = (hearings + h).sortedBy { Jalali.jdnOf(Jalali.JDate(it.jy, it.jm, it.jd)) }
                    Store.saveHearings(ctx, hearings)
                    showAddHearing = false
                }
            )
        }
        editHearing?.let { h ->
            HearingDialog(
                initial = h,
                cases = cases,
                onDismiss = { editHearing = null },
                onSave = { nh ->
                    hearings = hearings.map { if (it.id == h.id) nh else it }
                        .sortedBy { Jalali.jdnOf(Jalali.JDate(it.jy, it.jm, it.jd)) }
                    Store.saveHearings(ctx, hearings)
                    editHearing = null
                }
            )
        }
    }
}

// ---------------- Home ----------------

@Composable
fun HomeScreen(
    cases: List<CaseItem>,
    clients: List<Client>,
    hearings: List<Hearing>,
    modifier: Modifier = Modifier,
    onAddCase: () -> Unit,
    onOpenCases: () -> Unit,
    onOpenHearings: () -> Unit
) {
    val upcoming = hearings
        .filter { Jalali.jdnOf(Jalali.JDate(it.jy, it.jm, it.jd)) >= Jalali.todayJdn() }
        .take(2)
    val activeCount = cases.count { it.status == "در جریان" || it.status == "در انتظار اقدام" }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("دادآرا", color = Navy, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Text("هوشمندانه در مسیر عدالت", color = Muted, fontSize = 12.sp)
                }
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(Navy, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("⚖", color = Gold, fontSize = 25.sp)
                }
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Navy),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("پنل کاری وکیل", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    val t = Jalali.today()
                    Text("امروز ${Jalali.format(t)}", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("پرونده‌ها و جلساتتان را منظم و متمرکز مدیریت کنید.", color = Color(0xFFD6DCE6), fontSize = 12.sp)
                    Button(
                        onClick = onAddCase,
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("＋ ثبت پرونده جدید", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                SummaryCard("پرونده فعال", activeCount.toString(), "▤", Modifier.weight(1f))
                SummaryCard("موکلان", clients.size.toString(), "♙", Modifier.weight(1f))
                SummaryCard("جلسات پیش‌رو", upcoming.size.toString(), "◷", Modifier.weight(1f))
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("جلسات نزدیک", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("مشاهده همه", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onOpenHearings() })
            }
        }
        if (upcoming.isEmpty()) {
            item { EmptyState("جلسه‌ای ثبت نشده است", "از تب «جلسات» جلسه دادرسی بعدی را اضافه کنید.") }
        } else {
            items(upcoming) { h -> HearingCard(h, onEdit = {}, onDelete = {}) }
        }
        item {
            Text("پرونده‌های اخیر", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        if (cases.isEmpty()) {
            item { EmptyState("هنوز پرونده‌ای ثبت نشده است", "برای شروع، پرونده جدیدی اضافه کنید.") }
        } else {
            items(cases.take(3)) { case -> CaseCard(case, onEdit = {}, onDelete = {}) }
        }
        item {
            Text(
                "داده‌ها به‌صورت محلی روی همین گوشی ذخیره می‌شوند.",
                color = Muted,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            )
        }
    }
}

@Composable
fun SummaryCard(label: String, value: String, icon: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 15.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(icon, color = Gold, fontSize = 21.sp)
            Text(value, color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Muted, fontSize = 11.sp)
        }
    }
}

// ---------------- Cases ----------------

@Composable
fun CasesScreen(
    cases: List<CaseItem>,
    modifier: Modifier = Modifier,
    onAddCase: () -> Unit,
    onEditCase: (CaseItem) -> Unit,
    onDeleteCase: (CaseItem) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = if (query.isBlank()) cases
        else cases.filter {
            it.title.contains(query) || it.client.contains(query) || it.caseNumber.contains(query)
        }

    Column(modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 18.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("پرونده‌های من", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
                Text("مدیریت و پیگیری پرونده‌ها", color = Muted, fontSize = 12.sp)
            }
            Button(
                onClick = onAddCase,
                colors = ButtonDefaults.buttonColors(containerColor = Navy),
                shape = RoundedCornerShape(12.dp)
            ) { Text("＋ جدید", color = Color.White) }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("جست‌وجوی موضوع، موکل یا شماره…", fontSize = 13.sp) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        if (filtered.isEmpty()) {
            EmptyState(
                if (query.isBlank()) "پرونده‌ای وجود ندارد" else "نتیجه‌ای پیدا نشد",
                if (query.isBlank()) "با دکمه «جدید» اولین پرونده را ثبت کنید." else "عبارت دیگری را جست‌وجو کنید."
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(filtered) { CaseCard(it, onEdit = onEditCase, onDelete = onDeleteCase) }
            }
        }
    }
}

@Composable
fun CaseCard(item: CaseItem, onEdit: (CaseItem) -> Unit, onDelete: (CaseItem) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(15.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(42.dp).background(Cream, CircleShape),
                contentAlignment = Alignment.Center
            ) { Text("▤", color = Gold, fontSize = 20.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(item.title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("موکل: ${item.client}", color = Muted, fontSize = 12.sp)
                Text("شماره: ${item.caseNumber}", color = Muted, fontSize = 11.sp)
            }
            Surface(color = Color(Statuses.bg(item.status)), shape = RoundedCornerShape(8.dp)) {
                Text(item.status, color = Color(Statuses.color(item.status)), fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
            }
            Box {
                Text("⋮", color = Muted, fontSize = 18.sp,
                    modifier = Modifier
                        .clickable { menu = true }
                        .padding(start = 6.dp, top = 2.dp, bottom = 2.dp, end = 4.dp))
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("ویرایش") }, onClick = { menu = false; onEdit(item) })
                    DropdownMenuItem(text = { Text("حذف", color = Color(0xFFB3261E)) }, onClick = { menu = false; onDelete(item) })
                }
            }
        }
    }
}

@Composable
fun CaseDialog(
    initial: CaseItem? = null,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, String, String) -> Unit
) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var client by remember { mutableStateOf(initial?.client ?: "") }
    var number by remember { mutableStateOf(initial?.caseNumber ?: "") }
    var court by remember { mutableStateOf(initial?.court ?: "") }
    var status by remember { mutableStateOf(initial?.status ?: "در جریان") }
    var note by remember { mutableStateOf(initial?.note ?: "") }
    var error by remember { mutableStateOf(false) }
    var statusMenu by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = SurfaceWhite)) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(20.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    if (initial == null) "ثبت پرونده جدید" else "ویرایش پرونده",
                    color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold
                )
                OutlinedTextField(value = title, onValueChange = { title = it; error = false },
                    label = { Text("موضوع پرونده *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = client, onValueChange = { client = it },
                    label = { Text("نام موکل") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = number, onValueChange = { number = it },
                    label = { Text("شماره پرونده / کلاسه") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = court, onValueChange = { court = it },
                    label = { Text("مرجع (دادگاه / شورای حل اختلاف)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Box {
                    OutlinedTextField(
                        value = status,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("وضعیت") },
                        trailingIcon = { Text("▾", color = Muted) },
                        modifier = Modifier.fillMaxWidth().clickable { statusMenu = true }
                    )
                    DropdownMenu(expanded = statusMenu, onDismissRequest = { statusMenu = false }) {
                        Statuses.all.forEach { s ->
                            DropdownMenuItem(text = { Text(s) }, onClick = { status = s; statusMenu = false })
                        }
                    }
                }
                OutlinedTextField(value = note, onValueChange = { note = it },
                    label = { Text("یادداشت") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                if (error) Text("لطفاً موضوع پرونده را وارد کنید.", color = Color.Red, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("انصراف") }
                    Button(
                        onClick = {
                            if (title.isBlank()) error = true
                            else onSave(
                                title.trim(),
                                client.ifBlank { "ثبت نشده" }.trim(),
                                number.ifBlank { "ثبت نشده" }.trim(),
                                court.ifBlank { "—" }.trim(),
                                status,
                                note.trim()
                            )
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Navy)
                    ) { Text("ذخیره", color = Color.White) }
                }
            }
        }
    }
}

// ---------------- Hearings ----------------

@Composable
fun HearingsScreen(
    hearings: List<Hearing>,
    cases: List<CaseItem>,
    modifier: Modifier = Modifier,
    onAdd: () -> Unit,
    onEdit: (Hearing) -> Unit,
    onDelete: (Hearing) -> Unit
) {
    Column(modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 18.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("جلسات و یادآورها", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
                Text("تقویم شمسی جلسات دادرسی", color = Muted, fontSize = 12.sp)
            }
            Button(
                onClick = onAdd,
                colors = ButtonDefaults.buttonColors(containerColor = Navy),
                shape = RoundedCornerShape(12.dp)
            ) { Text("＋ جدید", color = Color.White) }
        }
        Spacer(Modifier.height(14.dp))
        if (hearings.isEmpty()) {
            EmptyState("جلسه‌ای ثبت نشده است", "با دکمه «جدید» جلسه یا یادآور اضافه کنید.")
        } else {
            val todayJdn = Jalali.todayJdn()
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(hearings) { h ->
                    val past = Jalali.jdnOf(Jalali.JDate(h.jy, h.jm, h.jd)) < todayJdn
                    Column {
                        HearingCard(h, onEdit = onEdit, onDelete = onDelete, past = past)
                    }
                }
            }
        }
    }
}

@Composable
fun HearingCard(h: Hearing, onEdit: (Hearing) -> Unit, onDelete: (Hearing) -> Unit, past: Boolean = false) {
    var menu by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(modifier = Modifier.padding(15.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(if (past) Color(0xFFE8EBF0) else Navy, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(fa(h.jd), color = if (past) Muted else Gold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(Jalali.monthNames[h.jm - 1].take(4), color = if (past) Muted else Color(0xFFD6DCE6), fontSize = 8.sp)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(h.title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("پرونده: ${h.caseTitle}", color = Muted, fontSize = 11.sp)
                val wd = Jalali.weekdayName(Jalali.j2d(h.jy, h.jm, h.jd))
                Text(
                    "$wd، ${Jalali.format(Jalali.JDate(h.jy, h.jm, h.jd))}" +
                        if (h.time.isNotBlank()) " — ساعت ${faTime(h.time)}" else "",
                    color = Muted, fontSize = 11.sp
                )
                if (h.place.isNotBlank()) Text("مکان: ${h.place}", color = Muted, fontSize = 11.sp)
            }
            if (past) {
                Surface(color = Color(0xFFE8EBF0), shape = RoundedCornerShape(8.dp)) {
                    Text("برگزار شد", color = Muted, fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                }
            }
            Box {
                Text("⋮", color = Muted, fontSize = 18.sp,
                    modifier = Modifier.clickable { menu = true }.padding(start = 6.dp))
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("ویرایش") }, onClick = { menu = false; onEdit(h) })
                    DropdownMenuItem(text = { Text("حذف", color = Color(0xFFB3261E)) }, onClick = { menu = false; onDelete(h) })
                }
            }
        }
    }
}

@Composable
fun HearingDialog(
    initial: Hearing? = null,
    cases: List<CaseItem>,
    onDismiss: () -> Unit,
    onSave: (Hearing) -> Unit
) {
    var title by remember { mutableStateOf(initial?.title ?: "جلسه دادرسی") }
    var caseTitle by remember { mutableStateOf(initial?.caseTitle ?: (cases.firstOrNull()?.title ?: "")) }
    var dateText by remember {
        mutableStateOf(
            initial?.let { "${it.jy}/${Jalali.pad2(it.jm)}/${Jalali.pad2(it.jd)}" }
                ?: run { val t = Jalali.today(); "${t.jy}/${Jalali.pad2(t.jm)}/${Jalali.pad2(t.jd)}" }
        )
    }
    var timeText by remember { mutableStateOf(initial?.time?.ifBlank { "09:00" } ?: "09:00") }
    var place by remember { mutableStateOf(initial?.place ?: "") }
    var note by remember { mutableStateOf(initial?.note ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    var caseMenu by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = SurfaceWhite)) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(20.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    if (initial == null) "ثبت جلسه جدید" else "ویرایش جلسه",
                    color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold
                )
                Text("تاریخ را به شمسی وارد کنید، مثلاً ${faDigits("1404/08/15")}", color = Muted, fontSize = 11.sp)
                OutlinedTextField(value = title, onValueChange = { title = it },
                    label = { Text("عنوان جلسه") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Box {
                    OutlinedTextField(
                        value = caseTitle,
                        onValueChange = { caseTitle = it },
                        readOnly = cases.isNotEmpty(),
                        label = { Text("پرونده مرتبط") },
                        trailingIcon = { if (cases.isNotEmpty()) Text("▾", color = Muted) },
                        modifier = Modifier.fillMaxWidth().clickable(enabled = cases.isNotEmpty()) { caseMenu = true }
                    )
                    DropdownMenu(expanded = caseMenu, onDismissRequest = { caseMenu = false }) {
                        cases.forEach { c ->
                            DropdownMenuItem(text = { Text(c.title, fontSize = 13.sp) }, onClick = { caseTitle = c.title; caseMenu = false })
                        }
                    }
                }
                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it; error = null },
                    label = { Text("تاریخ (شمسی) *") },
                    placeholder = { Text("1404/08/15") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = timeText,
                    onValueChange = { timeText = it; error = null },
                    label = { Text("ساعت") },
                    placeholder = { Text("09:00") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(value = place, onValueChange = { place = it },
                    label = { Text("مکان (دادگاه / سالن)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = note, onValueChange = { note = it },
                    label = { Text("یادداشت") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = Color.Red, fontSize = 12.sp) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("انصراف") }
                    Button(
                        onClick = {
                            val d = parseJalali(dateText)
                            if (d == null) {
                                error = "تاریخ شمسی معتبر نیست (مثال: ۱۴۰۴/۰۸/۱۵)"
                                return@Button
                            }
                            val t = if (timeText.isBlank()) "" else parseTime(timeText)
                            if (timeText.isNotBlank() && t == null) {
                                error = "ساعت معتبر نیست (مثال: ۹:۳۰)"
                                return@Button
                            }
                            onSave(
                                Hearing(
                                    id = initial?.id ?: newId(),
                                    caseTitle = caseTitle.ifBlank { "بدون پرونده" },
                                    title = title.ifBlank { "جلسه دادرسی" },
                                    jy = d.jy, jm = d.jm, jd = d.jd,
                                    time = t ?: "",
                                    place = place.trim(),
                                    note = note.trim()
                                )
                            )
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Navy)
                    ) { Text("ذخیره", color = Color.White) }
                }
            }
        }
    }
}

// ---------------- Clients ----------------

@Composable
fun ClientsScreen(
    clients: List<Client>,
    cases: List<CaseItem>,
    modifier: Modifier = Modifier,
    onAdd: () -> Unit,
    onEdit: (Client) -> Unit,
    onDelete: (Client) -> Unit
) {
    var expandedId by remember { mutableStateOf<Long?>(null) }

    Column(modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 18.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("موکلان", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
                Text("اطلاعات تماس و پرونده‌های هر موکل", color = Muted, fontSize = 12.sp)
            }
            Button(
                onClick = onAdd,
                colors = ButtonDefaults.buttonColors(containerColor = Navy),
                shape = RoundedCornerShape(12.dp)
            ) { Text("＋ جدید", color = Color.White) }
        }
        Spacer(Modifier.height(14.dp))
        if (clients.isEmpty()) {
            EmptyState("موکلی ثبت نشده است", "با دکمه «جدید» اولین موکل را اضافه کنید.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(clients) { c ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable {
                            expandedId = if (expandedId == c.id) null else c.id
                        },
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        shape = RoundedCornerShape(18.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(Modifier.padding(15.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier.size(42.dp).background(Cream, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) { Text("♙", color = Gold, fontSize = 20.sp) }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(c.name, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    if (c.phone.isNotBlank())
                                        Text(faDigits(c.phone), color = Muted, fontSize = 12.sp)
                                }
                                Text(if (expandedId == c.id) "▴" else "▾", color = Muted)
                            }
                            if (expandedId == c.id) {
                                Spacer(Modifier.height(10.dp))
                                val clientCases = cases.filter { it.client == c.name }
                                if (c.note.isNotBlank()) {
                                    Text(c.note, color = Muted, fontSize = 12.sp)
                                    Spacer(Modifier.height(8.dp))
                                }
                                Text(
                                    if (clientCases.isEmpty()) "پرونده‌ای برای این موکل ثبت نشده"
                                    else "پرونده‌ها (${clientCases.size}):",
                                    color = Navy, fontSize = 12.sp, fontWeight = FontWeight.Bold
                                )
                                clientCases.forEach { pc ->
                                    Text("• ${pc.title} (${pc.status})", color = Muted, fontSize = 12.sp)
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { onEdit(c) }, contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)) {
                                        Text("ویرایش", fontSize = 12.sp)
                                    }
                                    OutlinedButton(
                                        onClick = { onDelete(c) },
                                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB3261E))
                                    ) { Text("حذف", fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ClientDialog(
    initial: Client? = null,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var note by remember { mutableStateOf(initial?.note ?: "") }
    var error by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = SurfaceWhite)) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    if (initial == null) "ثبت موکل جدید" else "ویرایش موکل",
                    color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold
                )
                OutlinedTextField(value = name, onValueChange = { name = it; error = false },
                    label = { Text("نام و نام خانوادگی *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it },
                    label = { Text("شماره تماس") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = note, onValueChange = { note = it },
                    label = { Text("یادداشت") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                if (error) Text("لطفاً نام موکل را وارد کنید.", color = Color.Red, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("انصراف") }
                    Button(
                        onClick = {
                            if (name.isBlank()) error = true
                            else onSave(name.trim(), phone.trim(), note.trim())
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Navy)
                    ) { Text("ذخیره", color = Color.White) }
                }
            }
        }
    }
}

// ---------------- Shared ----------------

@Composable
fun EmptyState(title: String, subtitle: String) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("▤", color = Gold, fontSize = 38.sp)
        Spacer(Modifier.height(10.dp))
        Text(title, color = Navy, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(subtitle, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}
