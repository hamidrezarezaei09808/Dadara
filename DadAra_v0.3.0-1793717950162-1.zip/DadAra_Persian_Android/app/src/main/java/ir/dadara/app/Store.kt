package ir.dadara.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

// ---------------- Models ----------------

data class Client(
    val id: Long,
    val name: String,
    val phone: String,
    val note: String
)

data class CaseItem(
    val id: Long,
    val title: String,
    val client: String,
    val caseNumber: String,
    val court: String,
    val status: String,
    val note: String,
    val createdAt: Long
)

data class Hearing(
    val id: Long,
    val caseTitle: String,
    val title: String,
    val jy: Int,
    val jm: Int,
    val jd: Int,
    val time: String,
    val place: String,
    val note: String
)

// ---------------- Persistence (JSON files) ----------------

object Store {

    private fun file(ctx: Context, name: String) = java.io.File(ctx.filesDir, name)

    private fun readArray(ctx: Context, name: String): JSONArray {
        return try {
            JSONArray(file(ctx, name).readText())
        } catch (e: Exception) {
            JSONArray()
        }
    }

    private fun writeArray(ctx: Context, name: String, arr: JSONArray) {
        try {
            file(ctx, name).writeText(arr.toString())
        } catch (e: Exception) {
            // ignore write failure in demo build
        }
    }

    // ----- Cases -----

    fun loadCases(ctx: Context): List<CaseItem> {
        val arr = readArray(ctx, "cases.json")
        val list = mutableListOf<CaseItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                CaseItem(
                    id = o.optLong("id", 0L),
                    title = o.optString("title", ""),
                    client = o.optString("client", ""),
                    caseNumber = o.optString("caseNumber", ""),
                    court = o.optString("court", ""),
                    status = o.optString("status", "در جریان"),
                    note = o.optString("note", ""),
                    createdAt = o.optLong("createdAt", 0L)
                )
            )
        }
        return list
    }

    fun saveCases(ctx: Context, cases: List<CaseItem>) {
        val arr = JSONArray()
        cases.forEach { c ->
            arr.put(
                JSONObject()
                    .put("id", c.id)
                    .put("title", c.title)
                    .put("client", c.client)
                    .put("caseNumber", c.caseNumber)
                    .put("court", c.court)
                    .put("status", c.status)
                    .put("note", c.note)
                    .put("createdAt", c.createdAt)
            )
        }
        writeArray(ctx, "cases.json", arr)
    }

    // ----- Clients -----

    fun loadClients(ctx: Context): List<Client> {
        val arr = readArray(ctx, "clients.json")
        val list = mutableListOf<Client>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                Client(
                    id = o.optLong("id", 0L),
                    name = o.optString("name", ""),
                    phone = o.optString("phone", ""),
                    note = o.optString("note", "")
                )
            )
        }
        return list
    }

    fun saveClients(ctx: Context, clients: List<Client>) {
        val arr = JSONArray()
        clients.forEach { c ->
            arr.put(
                JSONObject()
                    .put("id", c.id)
                    .put("name", c.name)
                    .put("phone", c.phone)
                    .put("note", c.note)
            )
        }
        writeArray(ctx, "clients.json", arr)
    }

    // ----- Hearings -----

    fun loadHearings(ctx: Context): List<Hearing> {
        val arr = readArray(ctx, "hearings.json")
        val list = mutableListOf<Hearing>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                Hearing(
                    id = o.optLong("id", 0L),
                    caseTitle = o.optString("caseTitle", ""),
                    title = o.optString("title", "جلسه دادرسی"),
                    jy = o.optInt("jy", 0),
                    jm = o.optInt("jm", 0),
                    jd = o.optInt("jd", 0),
                    time = o.optString("time", ""),
                    place = o.optString("place", ""),
                    note = o.optString("note", "")
                )
            )
        }
        return list
    }

    fun saveHearings(ctx: Context, hearings: List<Hearing>) {
        val arr = JSONArray()
        hearings.forEach { h ->
            arr.put(
                JSONObject()
                    .put("id", h.id)
                    .put("caseTitle", h.caseTitle)
                    .put("title", h.title)
                    .put("jy", h.jy)
                    .put("jm", h.jm)
                    .put("jd", h.jd)
                    .put("time", h.time)
                    .put("place", h.place)
                    .put("note", h.note)
            )
        }
        writeArray(ctx, "hearings.json", arr)
    }
}

// ---------------- Helpers ----------------

object Statuses {
    val all = listOf("در جریان", "در انتظار اقدام", "مختومه", "منتفی")

    fun color(status: String): Long = when (status) {
        "در جریان" -> 0xFF28734B
        "در انتظار اقدام" -> 0xFF8A6A12
        "مختومه" -> 0xFF4A5568
        else -> 0xFF8B3A3A
    }

    fun bg(status: String): Long = when (status) {
        "در جریان" -> 0xFFEAF3ED
        "در انتظار اقدام" -> 0xFFFFF4D6
        "مختومه" -> 0xFFE8EBF0
        else -> 0xFFF7E5E5
    }
}

fun newId(): Long = System.currentTimeMillis()
